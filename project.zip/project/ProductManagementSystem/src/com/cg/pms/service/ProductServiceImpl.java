package com.cg.pms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.dao.ProductDao;
import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.exception.ProductException;

public class ProductServiceImpl implements ProductService {
	ProductDao pdao=new ProductDaoImpl();
		
		@Override
		public List<Product>showAllProduct() throws ProductException {
			
			return pdao.showAllProduct();
		}
		
		
		
		@Override
		public int deleteProduct(int productId) throws ProductException {
			// TODO Auto-generated method stub
			return pdao.deleteProduct(productId);
		}
		
		
		
		@Override
		public int addOrder(Order order) {
			order.setAmount(order.getQuantity()*order.getProduct().getPrice());
			return pdao.addOrder(order);
		}
	

	@Override
	public int addProduct(Product product) {
		
		return pdao.addProduct(product) ;
	}

	@Override
	public Product searchProduct(int productId) throws ProductException {
		
		return pdao.searchProduct(productId);
	}

	

	

	
	@Override
	public boolean validateProduct(Product product) throws ProductException {
		if(product.getPrice()<=0)
		{
			throw new ProductException("product price should not be 0 or negative");
		}
		if(!Pattern.matches("[A-Z][a-z0-9]{3,15}",product.getProductName())){
			throw new ProductException("product name should start with capital letter and min of 4 letters");
		}
		return true;
	}

	@Override
	public boolean validateOrder(Order order) throws ProductException {
		
		if(order.getQuantity()<=0)
		{
			throw new ProductException("product Quantity should not be 0 or negative");
		}
		return true;
		
		
	}

}
