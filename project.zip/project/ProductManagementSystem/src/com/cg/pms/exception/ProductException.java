package com.cg.pms.exception;

public class ProductException extends Exception  {


	public ProductException()
	{

	}
	public ProductException(String arg0)
	{
		super(arg0);

	}
	public ProductException(Throwable arg0)
	{
		super(arg0);
	}

	public ProductException(String arg0,Throwable arg1)
	{
		super(arg0);
	}
}
