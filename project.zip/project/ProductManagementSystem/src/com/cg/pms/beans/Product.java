package com.cg.pms.beans;

public class Product {
private int productId;
private int quantity;
private String productName;
private double price;
static int generator=0;

public int getProductId() {
	return productId;
}
public Product()
{
	productId=++generator;	
}

public Product(String productName, double price) {
	productId=++generator;
	this.productName = productName;
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + "]";
}

}
