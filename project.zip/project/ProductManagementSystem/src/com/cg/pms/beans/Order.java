package com.cg.pms.beans;

public class Order {
	
	private int orderId;
	private Product product;
	private int quantity;
	private double amount;
	static int generator=0;
	
	public Order()
	{
		orderId=++generator;
		
	}
	
	public Order(Product product, int quantity, double amount) {
		orderId=++generator;
		this.product = product;
		this.quantity = quantity;
		this.amount = amount;
	}



	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

@Override
public String toString() {
	return "order[product=" + product + ", quantity=" + quantity
			 + ", amount=" + amount+ "]";
}
}
