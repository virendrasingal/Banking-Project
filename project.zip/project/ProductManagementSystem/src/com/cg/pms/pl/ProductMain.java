package com.cg.pms.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exception.ProductException;
import com.cg.pms.service.ProductService;
import com.cg.pms.service.ProductServiceImpl;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

		ProductService pser=new ProductServiceImpl();
		do
		{

			System.out.println("Menu");
			System.out.println("1.add product in list");
			System.out.println("2.delete product from list");
			System.out.println("3.show product list");
			System.out.println("4.place order");
			System.out.println("5.Exit");


			System.out.println("enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:System.out.println("enter product name");
			String pname=sc.next();


			System.out.println("enter product price");
			double  price =sc.nextDouble();
			Product p=new Product(pname,price);

			try{

				if(pser.validateProduct(p))
				{
					int pid=pser.addProduct(p);
					System.out.println("product added with d :"+pid);
				}

			}
			catch(ProductException e2)
			{
				System.out.println(e2.getMessage());
			}
			break;

			case 2:System.out.println("enter product id to delete:");
			int pid1=sc.nextInt();
			try
			{
				pser.deleteProduct(pid1);
				System.out.println("product delete with id"+pid1);

			}
			catch(ProductException e1)
			{
				System.out.println(e1.getMessage());
			}





			break;
			case 3:
				try{
					List<Product> plist=pser.showAllProduct();
					for(Product p1:plist)
					{
						System.out.println(p1);
					}
				}
				catch(ProductException e){
					System.out.println(e.getMessage());
				}





				break;
			case 4:

				System.out.println("enter product id to order");
				int pid2=sc.nextInt();
				System.out.println("enter quantity");
				int qty=sc.nextInt();
				Product p1;
				try{
					p1=pser.searchProduct(pid2);

					Order order=new Order(p1,qty,0);
					int oid=pser.addOrder(order);
					System.out.println("order placed with id "+oid);
					System.out.println("you need to pay amount"+order.getAmount());
				}
				catch(ProductException e4)
				{
					System.out.println(e4.getMessage());
				}




				break;
			case 5:System.exit(0);
			default: System.out.println("invalid choice");

			}



		}while(true);

	}
}