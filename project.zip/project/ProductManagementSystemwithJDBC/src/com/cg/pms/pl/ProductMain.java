package com.cg.pms.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.pms.beans.Order;
import com.cg.pms.beans.Product;
import com.cg.pms.exceptions.InvalidOrderException;
import com.cg.pms.exceptions.InvalidProductException;
import com.cg.pms.exceptions.ProductDBException;
import com.cg.pms.service.ProductService;
import com.cg.pms.service.ProductServiceImpl;

public class ProductMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ProductService pser = new ProductServiceImpl();
		do {
			System.out.println("Menu \n 1. Add Product");
			System.out.println("2. Delete Product\n 3. Show all Product");
			System.out.println("4. Place Order\n 5. Exit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter Product Name :");
				String pname = sc.next();
				System.out.println("Enter Product Price:");
				double price = sc.nextDouble();
				Product p = new Product(0, pname, price);
				try {
					if(pser.validateProduct(p)){
						pser.addProduct(p);
						System.out.println("Product inserted in table with id "+p.getProductId());
					}
				} catch (InvalidProductException e) {
					System.out.println(e.getMessage());
				} catch (ProductDBException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:break;
			case 3:
				try {
					List<Product> plist = pser.getAllProduct();
					if(plist.size()==0){
						System.out.println("No Product available");
					}else{
						for(Product p1:plist){
							System.out.println(p1);
						}
					}
				} catch (ProductDBException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			case 4:
				System.out.println("Enter product id to order");
				int pid = sc.nextInt();
				System.out.println("Enter quantity :");
				int qty = sc.nextInt();
				System.out.println("Enter order date in dd/mm/yyyy format:");
				String ordDateStr = sc.next();
				DateTimeFormatter format = 
					DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate ordDate = LocalDate.parse(ordDateStr, format);
				Order order = new Order(0, pid, qty, 0, ordDate);
				try {
					if(pser.searchProduct(pid)== null){
						System.out.println("Product not available with "+pid);
					}else{
						if(pser.validatOrder(order)){
							pser.addOrder(order);
							System.out.println("Order placed with id "+order.getOrderId());
							System.out.println("Total amount to pay "+order.getTotalAmount());
						}
					}
				} catch (InvalidOrderException e) {
					System.out.println(e.getMessage());
				} catch (ProductDBException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5: System.exit(0);
			default: System.out.println("Invalid Choice try again");
			}
		} while (true);
	}
}
