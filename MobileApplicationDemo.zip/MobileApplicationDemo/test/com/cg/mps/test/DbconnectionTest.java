package com.cg.mps.test;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobile.dao.MobileDao;
import com.cg.mobile.exception.mobileException;
import com.cg.mobile.util.Dbconnection;

public class DbconnectionTest {

	
	static MobileDao daotest;
	static Connection dbcon;
	
	
	@BeforeClass
	public static void initialise() {
		
		daotest=new MobileDao();
		dbcon=null;
		}


	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws mobileException
	 **/

	@Test(expected=mobileException.class)
	public void test() throws mobileException {
		Dbconnection.getInstance();
		Connection dbCon = Dbconnection.getConnection();
		Assert.assertNotNull(dbCon);
	}


	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}
	
	
	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbcon = null;
	}
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
