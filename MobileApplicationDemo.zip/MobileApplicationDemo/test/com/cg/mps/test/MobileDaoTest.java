package com.cg.mps.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.mobile.dao.MobileDao;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.mobileException;

public class MobileDaoTest {

	static MobileDao dao;
	static PurchaseDetails purchaseDetails;
	
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new MobileDao();
		purchaseDetails = new PurchaseDetails();
	}
	
	
	/************************************
	 * Test case for addPurchaseDetail()
	 * 
	 ************************************/

	
	
	@Test
	public void testAddPurchaseDetails() throws mobileException {
		DateTimeFormatter fmt= DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse("11-02-2019", fmt);
		purchaseDetails.setCname("virendra");
		purchaseDetails.setMailid("abc@gmail.com");
		purchaseDetails.setPhoneno("9876543210");
		purchaseDetails.setPurchaseDate(date);
		purchaseDetails.setMobileid(1003);
		int id=dao.addPurchaseDetail(purchaseDetails);
		
		int expectedId=id+1;
		System.out.println(id);
		//assertTrue("Data Inserted successfully");
		//assertEquals(expectedId,dao.addPurchaseDetail(purchaseDetails));
		System.out.println(id+" "+dao.addPurchaseDetail(purchaseDetails));		

	}
	
	@Test
	public void testSearchMobile() throws mobileException{
		
		assertNotNull(dao.searchMobile(1001));
		
	}
	
	


	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws mobileException {
		assertNotNull(dao.getAllMobileDetails());
	}
	
	@Test
	public void testViewAllForValues() throws mobileException {
		assertTrue(dao.getAllMobileDetails().isEmpty()==false);
	
	}
	
	/********************************************
	 * Test case for deleteDetails()
	 ************************************************/
	
	@Test
	public void testById() throws mobileException {
		assertNotNull(dao.deleteRow(1004));
	}

	
	/********************************************
	 * Test case for searchDetails()
	 ************************************************/
	

	@Test
	public void testByPrice() throws mobileException {
		assertNotNull(dao.searchMobileOnPriceBased(40000));
	}
	
	
	
	
	
	
}
