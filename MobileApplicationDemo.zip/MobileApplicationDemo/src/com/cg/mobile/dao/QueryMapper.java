package com.cg.mobile.dao;

public interface QueryMapper {
	public static final String PURCHASEID_SEQUENCE_QUERY="SELECT purchaseid_seq.NEXTVAL FROM DUAL";
	public static final String INSERT_PURCHASE_DETAILS="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
	public static final String UPDATE_MOBILE_QUANTITY="UPDATE mobiles SET quantity=quantity-1 WHERE mobileid=?";
	public static final String SEARCH_MOBILE_QUERY="SELECT * FROM mobiles WHERE price<=?";
	public static final String DELETE_MOBILE_QUERY="DELETE from mobiles WHERE mobileid=?";
	public static final String SHOW_ALL_DETAILS="SELECT * FROM mobiles";
	

}
