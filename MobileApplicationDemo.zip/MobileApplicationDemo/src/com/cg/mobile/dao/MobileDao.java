package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.mobileException;
import com.cg.mobile.util.Dbconnection;

public class MobileDao implements IMobileDao{


	Logger logger=Logger.getRootLogger();
	Connection con=null;
	public MobileDao() {
		con=Dbconnection.getConnection();
		PropertyConfigurator.configure("resource//log4j.properties");
	}
	int generatePurchaseId(){
		int purchaseid=0;
		String sql="select purchaseid_seq.nextval from dual";
		try{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			if(rs.next())
				purchaseid=rs.getInt(1);
		}catch(SQLException e){
			logger.info("purchase id not create:");		
			
		}
			
		return purchaseid;
	}
	@Override
	public int addPurchaseDetail(PurchaseDetails purchaseDetails) throws mobileException {
		int queryResult=0;

		try{
			PreparedStatement ps=con.prepareStatement(QueryMapper.INSERT_PURCHASE_DETAILS);
			int purchaseid= generatePurchaseId();
			ps.setInt(1, purchaseid);
			ps.setString(2, purchaseDetails.getCname());
			ps.setString(3, purchaseDetails.getMailid());
			ps.setString(4, purchaseDetails.getPhoneno());
			ps.setDate(5, Date.valueOf(purchaseDetails.getPurchaseDate()));
			ps.setInt(6, purchaseDetails.getMobileid());
			int r=ps.executeUpdate();
			PreparedStatement ps1=con.prepareStatement(QueryMapper.UPDATE_MOBILE_QUANTITY);
			ps1.setLong(1, purchaseDetails.getMobileid());
			queryResult=ps1.executeUpdate();
			if(r==1)
				return purchaseid;
			
			
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new mobileException("Inserting details failed ");

			}
			else
			{
				logger.info("insert details added successfully:");
				return purchaseid;
			}
			
			
			
		}
		catch(SQLException e)
		{
			System.err.println("failed adding  details"+e.getMessage());
		}

		return 0;
	}

	
	
	
	@Override
	public ArrayList<MobileDetails> getMobileDetail() throws mobileException {
		ArrayList<MobileDetails> list=new ArrayList<>();
		try{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select mobileid,name from mobiles");
			while(rs.next()){
				MobileDetails mobDt=new MobileDetails();
				mobDt.setMobileid(rs.getInt(1));
				mobDt.setName(rs.getString(2));
				list.add(mobDt);
			}
		}catch(SQLException e){
			System.err.println("wrong mobile or name");
		}

		
		return list;
	}
	
	
	
	
	@Override
	public ArrayList<MobileDetails> getAllMobileDetails() throws mobileException {
		ArrayList<MobileDetails> list=new ArrayList<>();
		try{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from mobiles");
			while(rs.next()){
				MobileDetails mobDetail=new MobileDetails();
				mobDetail.setMobileid(rs.getInt(1));
				mobDetail.setName(rs.getString(2));
				mobDetail.setPrice(rs.getInt(3));
				mobDetail.setQuantity(rs.getInt(4));
				list.add(mobDetail);
			}
		}catch(SQLException e){
			logger.error("mobile details does not exist");	

			System.err.println("error in fetching details");
		}


		
		return list;
	}
	
	
	
	@Override
	public int deleteRow(int mobileid) throws mobileException {
		Connection con=Dbconnection.getConnection();
		try{
			PreparedStatement ps= con.prepareStatement(QueryMapper.DELETE_MOBILE_QUERY);
			ps.setInt(1, mobileid);
			int res=ps.executeUpdate();
			System.out.println("row deleted");
			return res ;
			
		}catch(SQLException e){
			logger.error("delete not possible");	

			System.err.println("error in deletion");	
		}

		return mobileid;
	}

	@Override
	public ArrayList<MobileDetails> searchMobileOnPriceBased(int price)throws mobileException {
		ArrayList<MobileDetails> list=new ArrayList<>();
		try{

			PreparedStatement ps= con.prepareStatement(QueryMapper.SEARCH_MOBILE_QUERY);
			ps.setInt(1, price);
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				MobileDetails mobDetail=new MobileDetails();
				mobDetail.setMobileid(rs.getInt(1));
				mobDetail.setName(rs.getString(2));
				mobDetail.setPrice(rs.getInt(3));
				mobDetail.setQuantity(rs.getInt(4));
				list.add(mobDetail);
			}
		}catch(SQLException e){
			System.err.println("error in searching");
		}


		
		return list;
	}





	public MobileDetails searchMobile(int mobileId) throws mobileException{
		String sql="SELECT mobileid from mobiles where mobileid=?";
		MobileDetails mob=null;
		Connection con=Dbconnection.getConnection();
		try {
			
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			ResultSet rs= ps.executeQuery();
			if(rs.next())
			{
				mob=new MobileDetails();
				mob.setMobileid(rs.getInt(1));
				

			}

		} catch (SQLException e) {
			logger.error("Error" + e.getMessage());
			throw new mobileException("mobile searching failed"+e.getMessage());

		}



		return mob;

	}







}
